<?php defined('IN_MET') or exit('No permission'); ?>
<include file="head.php" page="showdownload"/>
<ui name="download_list_detail" style="met_16_1" id="30" />
<ui name="sidebar" style="met_11_3" id="31" />
<include file="foot.php" />