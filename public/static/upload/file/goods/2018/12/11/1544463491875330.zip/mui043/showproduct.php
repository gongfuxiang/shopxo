<?php defined('IN_MET') or exit('No permission'); ?>
<include file="head.php" page="showproduct"/>
<ui name="location" style="met_16_1" id="28" />
<ui name="product_list_detail" style="met_16_1" id="29" />
<include file="foot.php" />