<?php defined('IN_MET') or exit('No permission'); ?>
<include file="head.php" page="index"/>
<ui name="product_list" style="met_11_4" id="5" />
<ui name="team_list" style="met_11_3" id="4" />
<ui name="service_list" style="met_11_4" id="3" />
<ui name="news_list" style="met_11_4" id="6" />
<ui name="about_list" style="met_11_4" id="7" />
<include file="foot.php" />