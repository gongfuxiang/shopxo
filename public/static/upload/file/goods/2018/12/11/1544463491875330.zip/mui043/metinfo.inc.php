<?php
global $metinfover;
// 模板引擎
$metinfover                  = "v2";
$template_type                  = "ui";
// 栏目可用字段
$metadmin[categorynamemark]  = 1; // 栏目修饰名称
$metadmin[categoryimage]     = 1; // 栏目图片
$metadmin[categorymarkimage] = 0; // 栏目标识图片

?>