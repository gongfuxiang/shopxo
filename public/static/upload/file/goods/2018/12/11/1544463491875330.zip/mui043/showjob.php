<?php defined('IN_MET') or exit('No permission'); ?>
<include file="head.php" page="showjob"/>
<include file="foot.php" />