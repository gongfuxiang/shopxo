<?php defined('IN_MET') or exit('No permission'); ?>
<include file="head.php" page="search"/>
<ui name="search" style="met_16_1" id="36" />
<include file="foot.php" />