<?php defined('IN_MET') or exit('No permission'); ?>
<include file="head.php" page="news"/>
<ui name="news_list_page" style="met_11_3" id="14" />
<ui name="sidebar" style="met_11_3" id="15" />
<include file="foot.php" />