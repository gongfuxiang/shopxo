<?php defined('IN_MET') or exit('No permission'); ?>
<include file="head.php" page="message_index"/>
<ui name="message_list" style="met_16_1" id="23" />
<ui name="message_form" style="met_16_1" id="24" />
<include file="foot.php" />