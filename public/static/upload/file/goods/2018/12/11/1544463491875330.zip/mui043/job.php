<?php defined('IN_MET') or exit('No permission'); ?>
<include file="head.php" page="job"/>
<ui name="job_list_page" style="met_16_1" id="22" />
<include file="foot.php" />