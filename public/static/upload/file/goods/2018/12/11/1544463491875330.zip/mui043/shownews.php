<?php defined('IN_MET') or exit('No permission'); ?>
<include file="head.php" page="shownews"/>
<ui name="news_list_detail" style="met_16_1" id="26" />
<ui name="sidebar" style="met_11_3" id="27" />
<include file="foot.php" />