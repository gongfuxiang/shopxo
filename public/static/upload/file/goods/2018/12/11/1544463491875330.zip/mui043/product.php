<?php defined('IN_MET') or exit('No permission'); ?>
<include file="head.php" page="product"/>
<ui name="subcolumn_nav" style="met_16_1" id="16" />
<ui name="para_search" style="met_16_1" id="17" />
<ui name="product_list_page" style="met_16_1" id="18" />
<include file="foot.php" />