<?php defined('IN_MET') or exit('No permission'); ?>
<include file="head.php" page="shop_showproduct"/>
<ui name="shopproduct_list_detail" style="met_16_1" id="34" />
<include file="foot.php" />