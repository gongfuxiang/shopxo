<?php defined('IN_MET') or exit('No permission'); ?>
<include file="head.php" page="show"/>
<ui name="subcolumn_nav" style="met_16_1" id="12" />
<ui name="show" style="met_16_1" id="13" />
<include file="foot.php" />