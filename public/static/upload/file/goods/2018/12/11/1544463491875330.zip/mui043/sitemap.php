<?php defined('IN_MET') or exit('No permission'); ?>
<include file="head.php" page="sitemap"/>
<ui name="sitemap" style="met_16_1" id="35" />
<include file="foot.php" />