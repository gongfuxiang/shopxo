<?php defined('IN_MET') or exit('No permission'); ?>
<include file="head.php" page="download"/>
<ui name="download_list_page" style="met_16_1" id="20" />
<ui name="sidebar" style="met_11_3" id="21" />
<include file="foot.php" />